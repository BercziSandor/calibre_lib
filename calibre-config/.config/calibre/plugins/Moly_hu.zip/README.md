# Calibre_Moly_hu
This [Calibre](https://calibre-ebook.com/) plugin has been created to download metadata and cover image from Moly.hu.

Original post from https://www.mobileread.com/forums/showthread.php?t=193302 by Kloon:
I must give credits to the original author, Daermond for making and publishing the initial plugin, but sadly he had abandoned it, so here I am taking over and fixing the errors that have popped up since.

Also, a big thumbs up for kiwidude, for sorting things out for me. 
And now an update by another author - fatsadt

## Main features:
Can retrieve title, author, series, ISBN, comments, tags, publisher, year of publication, rating and a cover images
Shows multiple results if possible (3 by default)
Search based on ISBN if present, otherwise based on title and/or author
Downloads multiple cover images if possible (5 by default)

## Special Notes:
Requires Calibre 5.0 or later.

## Installation Notes:
Download the attached zip file and install the plugin as described in the Introduction to plugins thread.
Note that this is not a GUI plugin so it is not intended/cannot be added to context menus/toolbars etc.

## Version History:
**Version 5.0.5** - 06 Jul 2024
Fix for Moly.hu changes to tags

## Version History:
**Version 5.0.4** - 03 Dec 2022
Fix for Moly.hu changes to text

## Version History:
**Version 5.0.3** - 03 Dec 2021
Some minor bug fixes

## Version History:
**Version 5.0.2** - 28 Nov 2021
isbn search error fix

## Version History:
**Version 5.0.1** - 04 Nov 2021
Fix for Moly.hu changes to tags code

## Version History:
**Version 4.1.7** - 26 Sep 2020
Version number change for Caliber 5

## Version History:
**Version 1.1.7** - 26 Sep 2020
Changes for Python 3 support in calibre.
Some minor bug fixes

## Version History:
**Version 1.1.6** - 26 Sep 2020
Changes for Python 3 support in calibre.
Some minor bug fixes

## Version History:
**Version 1.1.5** - 25 Sep 2020
Update: Changes for Python 3 support in calibre.

## Version History:
**Version 1.1.4** - 03 Jul 2020
Fix for search by ISBN

## Version History:
**Version 1.1.3** - 18 Jun 2020
Some minor bug fixes

## Version History:
**Version 1.1.2** - 18 Jun 2020
Ignore moly_hu in the 'identifier' field

## Version History:
**Version 1.1.1** - 18 Jun 2020
Fix for Moly.hu changes to html code (series)

## Version History:
**Version 1.1.0** - 17 Jun 2020
Fix for Moly.hu changes to html code (title)
Remove the ZWJ character from the title
Corrected italic text in the comment 
Remove double line breaks from the comment 
Remove "Vigyázat! Cselekményleírást tartalmaz." text from the comment

## Version History:
**Version 1.0.9** - 17 Jun 2020
Fix for Moly.hu changes to html code (title)

**Version 1.0.8** - 30 May 2018
Search primarily by isbn. (It's the most specific and accurate data. Try out the Extract ISBN plugin. With that the search is almost flawles)
If no match found fall back to broader search.
If no match try to remove () parts from title, after that try to remove authors.
Update by Dezso

**Version 1.0.7** -  8 May 2018
Find switched family-first names as well 
Update by otapi

**Version 1.0.6** - 11 April 2018
The filter of relevant title and author by transliterate the extended Hungarian characters
Update by otapi

**Version 1.0.5** - 29 March 2018
Search was too wide, now filters only to relevant title and author
Update by otapi

**Version 1.0.4** - 25 Jan 2017
Now working again, and searches for ISBNs
Update by fatsadt

**Version 1.0.3** - 2 Jan 2014
Can download multiple bigger cover images now
Reworked the plugin configuration

**Version 1.0.2** - 28 Jul 2013
Patched plugin to work with the new layout of moly.hu
Now parses language as well, so calibre will no longer capitalize Hungarian book titles

**Version 1.0.1** - 9 Oct 2012
Fix for Moly.hu changes to html code
Parses ISBN, publisher, year of publication as well
Raised max number of results to 12

**Version 1.0** - 08 May 2011
Initial release of plugin
